import boto3
import os
import cfnresponse
from botocore.exceptions import ClientError
import time
import json

# Environment variables
EKS_CLUSTER_NAME = 'EKS_CLUSTER_NAME'
ADDON_NAME = 'ADDON_NAME'
ADDON_VERSION = 'ADDON_VERSION'
EXECUTION_ROLE_ARN = 'EXECUTION_ROLE_ARN'
HYPERPOD_CLUSTER_ARN = 'HYPERPOD_CLUSTER_ARN'
TLS_CERTIFICATE_S3_BUCKET = 'TLS_CERTIFICATE_S3_BUCKET'
KEDA_ROLE_ARN = 'KEDA_ROLE_ARN'
ALB_CONTROLLER_ROLE_ARN = 'ALB_CONTROLLER_ROLE_ARN'
JUMPSTART_GATED_MODEL_ROLE_ARN = 'JUMPSTART_GATED_MODEL_ROLE_ARN'
INFERENCE_GATEWAY_ROLE_ARN = 'INFERENCE_GATEWAY_ROLE_ARN'
DYNAMO_ENABLED = 'DYNAMO_ENABLED'
# Minimum EKS add-on version whose config schema accepts the `dynamo` key.
# Keep in sync with DYNAMO_ADDON_VERSION in lib/utils/feature-flags.ts.
DYNAMO_MIN_ADDON_VERSION = 'v2.1.0-eksbuild.2'
ADDON_INSTALLATION_TIMEOUT = 'ADDON_INSTALLATION_TIMEOUT'

REQUIRED_ENV_VARS = [
    'EKS_CLUSTER_NAME',
    'EXECUTION_ROLE_ARN',
    'TLS_CERTIFICATE_S3_BUCKET',
    'KEDA_ROLE_ARN',
    'ALB_CONTROLLER_ROLE_ARN',
    'JUMPSTART_GATED_MODEL_ROLE_ARN'
]

# Tags
CREATED_BY_TAG_KEY = 'CreatedBy'
CREATED_BY_HYPERPOD_INFERENCE_TAG_VALUE = 'HyperPodInference'

# Addon status
ADDON_FAILED_STATUSES = ['CREATE_FAILED', 'UPDATE_FAILED', 'DELETE_FAILED']
ADDON_SUCCESS_STATUSES = ['ACTIVE', 'DEGRADED']

# Default timeout for addon installation in seconds (15 minutes for inference operator)
DEFAULT_ADDON_INSTALLATION_TIMEOUT_IN_SECONDS = 900

def lambda_handler(event, context):
    """
    Handle CloudFormation custom resource requests for managing Inference Operator addon
    
    IMPORTANT: This lambda ALWAYS returns SUCCESS to prevent CloudFormation rollback,
    achieving decoupling between inference operator failures and HyperPod cluster creation.
    The actual addon status is reported in the response data for UI consumption.
    """
    response_data = {
        'AddonArn': '',
        'AddonStatus': 'UNKNOWN',
        'OperationStatus': 'SUCCESS',
        'ErrorMessage': ''
    }
    try:
        request_type = event['RequestType']

        if request_type == 'Create':
            response_data = on_create()
        elif request_type == 'Update':
            response_data = on_update()
        elif request_type == 'Delete':
            response_data = on_delete()
        else:
            raise ValueError(f"Invalid request type: {request_type}")

    except Exception as e:
        print(f"Error occurred but returning SUCCESS to prevent stack rollback: {str(e)}")

    # ALWAYS send SUCCESS to CloudFormation to prevent rollback
    # UI can check OperationStatus and AddonStatus for actual status
    cfnresponse.send(
        event,
        context,
        cfnresponse.SUCCESS,
        response_data
    )

def get_addon_status(eks_client, cluster_name, addon_name):
    """
    Get current status of addon if it exists
    Returns: tuple (addon_arn, addon_status, addon_version) or (None, None, None) if not found
    """
    try:
        addon_info = eks_client.describe_addon(
            clusterName=cluster_name,
            addonName=addon_name
        )
        return (
            addon_info['addon']['addonArn'],
            addon_info['addon']['status'],
            addon_info['addon']['addonVersion']
        )
    except ClientError as e:
        if e.response['Error']['Code'] == 'ResourceNotFoundException':
            return None, None, None
        raise


def get_addon_health_issues(eks_client, cluster_name, addon_name):
    """
    Get health issues for an addon
    Returns: list of formatted error messages
    """
    addon_info = eks_client.describe_addon(
        clusterName=cluster_name,
        addonName=addon_name
    )
    health_issues = addon_info.get('addon', {}).get('health', {}).get('issues', [])
    return [f"{issue.get('code', 'Unknown')}: {issue.get('message', 'Unknown Error')}" for issue in health_issues]


def wait_for_addon_terminal_state(eks_client, cluster_name, addon_name):
    """
    Wait for addon to reach a terminal state
    """
    timeout = int(os.environ.get(ADDON_INSTALLATION_TIMEOUT, DEFAULT_ADDON_INSTALLATION_TIMEOUT_IN_SECONDS))
    start_time = time.time()
    
    while time.time() - start_time < timeout:
        addon_arn, status, version = get_addon_status(eks_client, cluster_name, addon_name)
        
        if not addon_arn:
            print("Addon no longer exists")
            return
        
        print(f"Addon {addon_name} status: {status}")
        
        # Check for failed states
        if status in ADDON_FAILED_STATUSES:
            error_messages = get_addon_health_issues(eks_client, cluster_name, addon_name)
            raise RuntimeError(f"Addon {addon_name} failed with status {status}. Issues: {'; '.join(error_messages)}")
        
        # Success terminal states
        if status in ADDON_SUCCESS_STATUSES:
            return
        
        time.sleep(30)
    
    # Timeout reached
    raise TimeoutError(f"Timeout waiting for addon {addon_name} moving to terminal state")


def _addon_version_key(version):
    """
    Parse an EKS add-on version into a comparable tuple including the eksbuild
    suffix, e.g. 'v2.1.0-eksbuild.2' -> (2, 1, 0, 2). Unlike compare_versions in
    version_utils (which ignores the suffix), this distinguishes eksbuild.1 from
    eksbuild.2, which matters because Dynamo support differs at that granularity.
    """
    v = (version or '').lstrip('v')
    main, _, suffix = v.partition('-')
    parts = []
    for p in main.split('.'):
        digits = ''
        for ch in p:
            if ch.isdigit():
                digits += ch
            else:
                break
        parts.append(int(digits) if digits else 0)
    while len(parts) < 3:
        parts.append(0)
    # Trailing integer of the build suffix, e.g. 'eksbuild.2' -> 2
    build_digits = ''
    for ch in reversed(suffix):
        if ch.isdigit():
            build_digits = ch + build_digits
        else:
            break
    build = int(build_digits) if build_digits else 0
    return (parts[0], parts[1], parts[2], build)


def is_dynamo_supported_version(addon_version):
    """
    True only when the resolved add-on version is at or above the minimum
    Dynamo-capable version. Returns False for an empty/unknown version so we
    never send the dynamo config to a version that would reject it.
    """
    if not addon_version:
        return False
    try:
        return _addon_version_key(addon_version) >= _addon_version_key(DYNAMO_MIN_ADDON_VERSION)
    except Exception as e:
        print("Warning: could not parse addon version '{}': {}".format(addon_version, e))
        return False


def resolve_effective_addon_version(eks, cluster_name, addon_name, requested_version, current_version=''):
    """
    Determine the add-on version that will actually be installed so the Dynamo
    gate can be decided against it (no version is pinned for Dynamo):
      1. an explicit requested version, if provided;
      2. the existing add-on's current version, if the add-on already exists;
      3. otherwise the EKS default version for the cluster's Kubernetes version.
    Returns '' if it cannot be resolved (treated as not Dynamo-capable).
    """
    if requested_version and requested_version.strip():
        return requested_version
    if current_version and current_version.strip():
        return current_version
    try:
        cluster = eks.describe_cluster(name=cluster_name)['cluster']
        k8s_version = cluster.get('version', '')
        response = eks.describe_addon_versions(addonName=addon_name, kubernetesVersion=k8s_version)
        for addon in response.get('addons', []):
            for addon_version in addon.get('addonVersions', []):
                for compatibility in addon_version.get('compatibilities', []):
                    if compatibility.get('defaultVersion'):
                        return addon_version.get('addonVersion', '')
    except Exception as e:
        print(f"Warning: could not resolve default add-on version: {str(e)}")
    return ''


def build_inference_operator_configuration(effective_addon_version=''):
    """
    Build the configuration JSON for the inference operator addon.

    effective_addon_version is the add-on version that will actually be installed
    (an explicit pin, the existing add-on's version, or the resolved EKS default).
    The dynamo config is only included when that version supports it.
    """
    execution_role_arn = os.environ.get('EXECUTION_ROLE_ARN', '')
    tls_certificate_s3_bucket = os.environ.get('TLS_CERTIFICATE_S3_BUCKET', '')
    keda_role_arn = os.environ.get('KEDA_ROLE_ARN', '')
    alb_controller_role_arn = os.environ.get('ALB_CONTROLLER_ROLE_ARN', '')
    jumpstart_gated_model_role_arn = os.environ.get('JUMPSTART_GATED_MODEL_ROLE_ARN', '')
    inference_gateway_role_arn = os.environ.get('INFERENCE_GATEWAY_ROLE_ARN', '')
    inference_gateway_enabled = os.environ.get('INFERENCE_GATEWAY_ENABLED', 'false').lower() == 'true'
    
    config = {
        "executionRoleArn": execution_role_arn,
        "tlsCertificateS3Bucket": tls_certificate_s3_bucket,
        "keda": {
            "enabled": True,
            "auth": {
                "aws": {
                    "irsa": {
                        "enabled": True,
                        "roleArn": keda_role_arn
                    }
                }
            }
        },
        "alb": {
            "enabled": True,
            "serviceAccount": {
                "create": True,
                "roleArn": alb_controller_role_arn
            }
        },
        "jumpstartGatedModelDownloadRoleArn": jumpstart_gated_model_role_arn
    }

    if inference_gateway_enabled:
        config["inferenceGateway"] = {
            "enabled": True,
            "serviceAccount": {
                "roleArn": inference_gateway_role_arn
            }
        }
    else:
        config["inferenceGateway"] = {
            "enabled": False
        }

    # NVIDIA Dynamo serving engine. Gated by TWO conditions:
    #   1) DYNAMO_FEATURE_ENABLED - the build-time feature flag (gamma-only until GA).
    #      When off, Dynamo is a no-op even if EnableDynamo=true, so the feature stays
    #      inert in stages where it has not been released.
    #   2) the effective add-on version must support the dynamo key (older versions
    #      have additionalProperties:false and would reject it); no version is pinned.
    # When both hold, the explicit enabled value is sent (so EnableDynamo=false is
    # honored rather than falling back to the schema default of on).
    dynamo_feature_enabled = os.environ.get('DYNAMO_FEATURE_ENABLED', 'false').lower() == 'true'
    dynamo_enabled = os.environ.get('DYNAMO_ENABLED', 'true').lower() == 'true'
    if dynamo_feature_enabled and is_dynamo_supported_version(effective_addon_version):
        config["dynamo"] = {
            "enabled": dynamo_enabled
        }

    return config


def is_addon_managed_by_inference(eks_client, addon_arn):
    """
    Check if addon was created by this stack by verifying the prerequisite tag
    Returns: bool
    """
    try:
        response = eks_client.list_tags_for_resource(resourceArn=addon_arn)
        tags = response.get('tags', {})
        
        # Check if our management tag exists
        has_tag = tags.get(CREATED_BY_TAG_KEY) == CREATED_BY_HYPERPOD_INFERENCE_TAG_VALUE
        return has_tag
    except Exception as e:
        print(f"Error checking addon tags: {str(e)}")
        # If we can't check tags, assume NOT managed by us for safety
        return False


def remove_addon(eks_client, cluster_name, addon_name):
    """
    Remove EKS addon and wait for deletion to complete
    """
    try:
        timeout = int(os.environ.get(ADDON_INSTALLATION_TIMEOUT, DEFAULT_ADDON_INSTALLATION_TIMEOUT_IN_SECONDS))
        print(f"Removing addon {addon_name}...")
        eks_client.delete_addon(
            clusterName=cluster_name,
            addonName=addon_name
        )
        
        # Wait for deletion
        start_time = time.time()
        while time.time() - start_time < timeout:
            check_arn, _, _ = get_addon_status(eks_client, cluster_name, addon_name)
            if not check_arn:
                print("Addon removed successfully")
                return
            time.sleep(10)
        
        raise TimeoutError(f"Timeout waiting for addon {addon_name} deletion to complete")
        
    except ClientError as e:
        if e.response['Error']['Code'] == 'ResourceNotFoundException':
            print(f"Addon {addon_name} not found during deletion, already deleted")
            return
        raise


def create_addon(cluster_name, addon_name, addon_version, configuration_values):
    """
    Create new inference operator EKS addon
    """
    try:
        eks = boto3.client('eks')
        
        create_params = {
            'clusterName': cluster_name,
            'addonName': addon_name,
            'resolveConflicts': 'OVERWRITE',
            'tags': {
                CREATED_BY_TAG_KEY: CREATED_BY_HYPERPOD_INFERENCE_TAG_VALUE
            },
        }
        
        if addon_version and addon_version.strip():
            create_params['addonVersion'] = addon_version
        
        if configuration_values:
            create_params['configurationValues'] = json.dumps(configuration_values)
        
        response = eks.create_addon(**create_params)
        
        print(f"Addon creation initiated: {response['addon']['addonArn']}")
        
        # Wait for terminal state
        wait_for_addon_terminal_state(eks, cluster_name, addon_name)
        
    except Exception as e:
        print(f"Error creating addon: {str(e)}")
        raise


def update_addon(cluster_name, addon_name, addon_version, configuration_values):
    """
    Update existing inference operator EKS addon
    """
    try:
        eks = boto3.client('eks')
        
        print(f"Updating addon {addon_name} to version {addon_version}...")
        
        update_params = {
            'clusterName': cluster_name,
            'addonName': addon_name,
            'resolveConflicts': 'OVERWRITE'
        }
        
        if addon_version and addon_version.strip():
            update_params['addonVersion'] = addon_version
        
        if configuration_values:
            update_params['configurationValues'] = json.dumps(configuration_values)
        
        eks.update_addon(**update_params)
        
        print("Addon update initiated")
        # Wait for update to complete
        wait_for_addon_terminal_state(eks, cluster_name, addon_name)
        
    except Exception as e:
        print(f"Error updating addon: {str(e)}")
        raise


def update_addon_version(cluster_name, addon_name, addon_version, current_version, configuration_values):
    """
    Handle version comparison and update logic for existing addons
    """
    if addon_version and addon_version.strip():
        # Version specified - compare with current version. Use the suffix-aware
        # key (not compare_versions, which ignores the eksbuild suffix) so an
        # eksbuild.1 -> eksbuild.2 upgrade is recognized instead of treated as
        # equal and skipped. Otherwise the new configuration (e.g. dynamo.enabled)
        # would never be applied to an add-on already installed at the same semver.
        if _addon_version_key(addon_version) > _addon_version_key(current_version):
            # New version is higher - update
            print(f"Addon {addon_name} already exists with version {current_version}, upgrading to {addon_version}...")
            update_addon(cluster_name, addon_name, addon_version, configuration_values)
        else:
            # Same or lower version - skip update
            print(f"Addon {addon_name} already exists with version {current_version} (requested: {addon_version}), skipping update")
    else:
        # No version specified - keep existing version
        print(f"Addon {addon_name} already exists with version {current_version}, no version specified, keeping current version")


def on_create():
    """
    Handle Create request to install inference operator EKS addon
    """
    try:
        # Ensure required environment variables are set
        for var in REQUIRED_ENV_VARS:
            if var not in os.environ:
                raise ValueError(f"Missing required environment variable: {var}")

        cluster_name = os.environ[EKS_CLUSTER_NAME]
        addon_name = os.environ.get(ADDON_NAME, 'amazon-sagemaker-hyperpod-inference')
        addon_version = os.environ.get(ADDON_VERSION, '')

        eks = boto3.client('eks')

        # Check if EKS addon already exists
        addon_arn, _, current_version = get_addon_status(eks, cluster_name, addon_name)

        # Resolve the version that will actually be installed so the Dynamo gate is
        # decided against the real version (no version is pinned for Dynamo).
        effective_version = resolve_effective_addon_version(
            eks, cluster_name, addon_name, addon_version, current_version if addon_arn else ''
        )
        configuration_values = build_inference_operator_configuration(effective_version)

        if addon_arn:
            # Addon exists - handle version update
            update_addon_version(
                cluster_name, addon_name, addon_version, current_version, configuration_values
            )
        else:
            # Create new EKS addon
            print(f"Addon {addon_name} not found, creating...")
            create_addon(cluster_name, addon_name, addon_version, configuration_values)
        
        final_arn, final_status, _ = get_addon_status(eks, cluster_name, addon_name)
        
        return {
            'AddonArn': final_arn or '',
            'AddonStatus': final_status or 'UNKNOWN',
            'OperationStatus': 'SUCCESS',
            'ErrorMessage': ''
        }
    
    except Exception as e:
        print(f"Error in on_create: {str(e)}")
        # Try to get current addon status for the error response
        try:
            cluster_name = os.environ.get(EKS_CLUSTER_NAME, '')
            addon_name = os.environ.get(ADDON_NAME, 'amazon-sagemaker-hyperpod-inference')
            eks = boto3.client('eks')
            final_arn, final_status, _ = get_addon_status(eks, cluster_name, addon_name)
        except Exception:
            final_arn = ''
        
        return {
            'AddonArn': final_arn or '',
            'AddonStatus': final_status or 'CREATE_FAILED',
            'OperationStatus': 'SUCCESS',
            'ErrorMessage': str(e)
        }


def on_update():
    """
    Handle Update request for inference operator EKS addon
    """
    # Ensure required environment variables are set
    for var in REQUIRED_ENV_VARS:
        if var not in os.environ:
            raise ValueError(f"Missing required environment variable: {var}")

    cluster_name = os.environ[EKS_CLUSTER_NAME]
    addon_name = os.environ.get(ADDON_NAME, 'amazon-sagemaker-hyperpod-inference')
    addon_version = os.environ.get(ADDON_VERSION, '')

    eks = boto3.client('eks')

    # Check if EKS addon exists
    addon_arn, addon_status, current_version = get_addon_status(eks, cluster_name, addon_name)

    # Resolve the version that will actually be installed so the Dynamo gate is
    # decided against the real version (no version is pinned for Dynamo).
    effective_version = resolve_effective_addon_version(
        eks, cluster_name, addon_name, addon_version, current_version if addon_arn else ''
    )
    configuration_values = build_inference_operator_configuration(effective_version)

    if addon_arn:
        # Throw error if addon is in unhealthy state
        if addon_status not in ADDON_SUCCESS_STATUSES:
            error_msg = (
                f"Addon {addon_name} is in {addon_status} state. "
                f"Please ensure addon is in {ADDON_SUCCESS_STATUSES} or remove the addon in FAILED state and retry."
            )
            raise RuntimeError(error_msg)
        
        # Addon exists and healthy - attempt version update
        update_addon_version(
            cluster_name, addon_name, addon_version, current_version, configuration_values
        )
    else:
        print(f"Addon {addon_name} not found, creating...")
        # Create new EKS addon
        create_addon(cluster_name, addon_name, addon_version, configuration_values)
    
    final_arn, final_status, _ = get_addon_status(eks, cluster_name, addon_name)
    
    return {
        'AddonArn': final_arn or '',
        'AddonStatus': final_status or 'UNKNOWN',
        'OperationStatus': 'SUCCESS',
        'ErrorMessage': ''
    }


def on_delete():
    """
    Handle Delete request to uninstall inference operator EKS addon
    """
    cluster_name = os.environ.get(EKS_CLUSTER_NAME)
    addon_name = os.environ.get(ADDON_NAME, 'amazon-sagemaker-hyperpod-inference')
    
    if not cluster_name:
        print("Cluster name not found, skipping cleanup")
        return {
            'AddonArn': '',
            'AddonStatus': 'NOT_FOUND',
            'OperationStatus': 'SUCCESS',
            'ErrorMessage': 'Cluster name not found, skipping cleanup'
        }
    
    eks = boto3.client('eks')

    # Check if addon exists before attempting deletion
    addon_arn, _, _ = get_addon_status(eks, cluster_name, addon_name)
    
    if addon_arn and is_addon_managed_by_inference(eks, addon_arn):
        # Delete addon only if it exists and is managed by us
        print(f"Deleting addon {addon_name} from cluster {cluster_name}...")
        remove_addon(eks, cluster_name, addon_name)
        return {
            'AddonArn': '',
            'AddonStatus': 'DELETED',
            'OperationStatus': 'SUCCESS',
            'ErrorMessage': ''
        }
    elif addon_arn:
        print(f"Addon {addon_name} was NOT created by hyperpod inference addon - skipping deletion")
        return {
            'AddonArn': addon_arn,
            'AddonStatus': 'SKIPPED_NOT_MANAGED',
            'OperationStatus': 'SUCCESS',
            'ErrorMessage': 'Addon not created by this stack, skipping deletion'
        }
    else:
        print(f"Addon {addon_name} not found, already deleted")
        return {
            'AddonArn': '',
            'AddonStatus': 'NOT_FOUND',
            'OperationStatus': 'SUCCESS',
            'ErrorMessage': ''
        }
